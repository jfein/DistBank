package core.node;

public interface NodeState {

}
