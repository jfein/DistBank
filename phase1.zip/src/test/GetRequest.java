package test;

import core.network.common.Message;

public class GetRequest extends Message {

	private static final long serialVersionUID = -1509507339425180933L;

}
