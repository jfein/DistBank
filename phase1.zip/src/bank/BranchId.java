package bank;

import core.node.NodeId;

public class BranchId extends NodeId {

	private static final long serialVersionUID = 7622797403116473347L;

	public BranchId(Integer id) {
		super(id);
	}

}
