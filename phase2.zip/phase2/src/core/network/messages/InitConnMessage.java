package core.network.messages;

public class InitConnMessage extends Message {

	private static final long serialVersionUID = 1L;

}
