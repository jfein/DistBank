package core.network.messages;

public abstract class Request extends Message {

	private static final long serialVersionUID = 1L;

}
