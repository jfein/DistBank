package core.network.messages;

public abstract class Response extends Message {

	private static final long serialVersionUID = -5624023138287704166L;

}
