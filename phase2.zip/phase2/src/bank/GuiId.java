package bank;

import core.node.NodeId;

public class GuiId extends NodeId {

	private static final long serialVersionUID = -4767192689389352324L;

	public GuiId(Integer id) {
		super(id);
	}

}
