package test;

import core.node.NodeState;

public class TestState extends NodeState {

	private int x;

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

}
