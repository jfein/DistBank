package test;

import core.network.messages.Request;

public class GetRequest extends Request {

	private static final long serialVersionUID = -1509507339425180933L;

}
